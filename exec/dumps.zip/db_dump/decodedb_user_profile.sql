-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: decode-db.c5qy4qwy880z.ap-northeast-2.rds.amazonaws.com    Database: decodedb
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `user_profile`
--

DROP TABLE IF EXISTS `user_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_profile` (
  `user_id` bigint NOT NULL,
  `user_coin` int DEFAULT NULL,
  `user_exp` int DEFAULT NULL,
  `user_nickname` varchar(255) DEFAULT NULL,
  `user_point` int DEFAULT NULL,
  `user_profile_img` varchar(255) DEFAULT NULL,
  `user_tier` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `UK_ps1q6lyu6an2a46f4rtlteaa` (`user_nickname`),
  CONSTRAINT `FKqn9hd9joc1cqolpc4io5wyv8n` FOREIGN KEY (`user_id`) REFERENCES `user_info` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_profile`
--

LOCK TABLES `user_profile` WRITE;
/*!40000 ALTER TABLE `user_profile` DISABLE KEYS */;
INSERT INTO `user_profile` VALUES (1,0,4764,'선맹',5340,'default','gold'),(2,0,4090,'34067179',5710,'default','bronze'),(3,0,34081,'RealSunmeng',10720,'default','platinum'),(4,0,9180,'모화',6980,'default','ruby'),(5,500,0,NULL,0,NULL,NULL),(6,0,940,'86655177',5290,'default','bronze'),(7,0,1750,'킹싸피',5830,'default','diamond'),(8,0,3550,'88009952',6160,'default','bronze'),(9,0,1531,'test',5510,'default','bronze'),(10,0,0,'tagtest',5000,'default','bronze'),(11,0,3,'서재화',5000,'default','bronze'),(12,0,37222,'강낭콩',6260,'default','silver'),(13,0,0,'Park123',5000,'default','bronze'),(14,0,0,'1',5000,'default','bronze'),(15,0,0,'시험중',5000,'default','bronze'),(16,0,0,'테스트중',5000,'default','bronze'),(17,0,0,'시험중임',5000,'default','bronze'),(18,0,180,'112466460',5060,'default','bronze'),(19,0,0,'테스트',5000,'default','bronze'),(20,0,0,'테스트중입니다',5000,'default','bronze'),(21,0,0,'가입',5000,'default','bronze'),(22,0,0,'있나',5000,'default','bronze'),(23,0,0,'되나',5000,'default','bronze'),(24,0,0,'되는가',5000,'default','bronze'),(25,0,0,'보자',5000,'default','bronze'),(26,0,0,'false',5000,'default','bronze'),(27,0,0,'통과되나',5000,'default','bronze'),(28,0,0,'되어라',5000,'default','bronze'),(29,0,0,'하느니라',5000,'default','bronze'),(30,0,0,'주라',5000,'default','bronze'),(31,0,0,'되어줘라',5000,'default','bronze'),(32,0,0,'머지',5000,'default','bronze'),(33,0,0,'머머지',5000,'default','bronze'),(34,0,0,'지지',5000,'default','bronze'),(35,0,0,'지이',5000,'default','bronze'),(36,0,4859,'부족해요',5750,'default','bronze'),(37,0,0,'2단계',5000,'default','bronze'),(38,0,0,'2단계로',5000,'default','bronze'),(39,0,0,'팡',5000,'default','bronze'),(40,0,0,'으음',5000,'default','bronze'),(41,0,0,'나',5000,'default','bronze'),(42,0,0,'이번에는',5000,'default','bronze'),(43,0,0,'가보자고',5000,'default','bronze'),(44,0,0,'id보자',5000,'default','bronze'),(45,0,0,'gi',5000,'default','bronze'),(46,0,0,'137035446',5000,'default','bronze'),(47,0,0,'되는것인가',5000,'default','bronze'),(48,0,0,'2단계가자',5000,'default','bronze'),(49,0,0,'보',5000,'default','bronze'),(50,0,1101,'히히',5110,'default','bronze'),(51,0,30,'139422554',5010,'default','bronze'),(52,0,3240,'chiikawa',5080,'default','bronze'),(53,0,0,'ssa',5000,'default','bronze'),(54,0,200,'선맹2',5020,'default','bronze'),(55,0,1900,'록바이슨',5190,'default','bronze'),(56,0,1400,'48899055',5210,'default','bronze'),(57,0,1100,'근보',5110,'default','bronze'),(58,0,1330,'80499642',5140,'default','bronze'),(59,0,0,'101111328',5000,'default','bronze'),(60,0,2000,'69035612',5200,'default','bronze'),(61,0,100,'uyuyuy',5010,'default','bronze'),(62,0,200,'고구맛탕',5020,'default','bronze'),(63,0,5900,'싸피킹',5590,'default','bronze'),(64,0,30,'admin',5010,'default','bronze'),(65,0,30,'48192100',5010,'default','bronze'),(66,0,7440,'Louis',7480,'default','bronze'),(68,0,360,'선재',5120,'default','bronze'),(69,0,330,'ggparty',5110,'default','bronze'),(70,0,30,'Park777',5010,'default','bronze'),(71,0,1050,'컨설턴트',5350,'default','bronze'),(72,0,30,'치타는웃고있다',5010,'default','bronze'),(73,0,0,'코린이',5000,'default','bronze'),(74,0,1170,'Park6531',5390,'default','bronze'),(75,0,30,'진또배기',5010,'default','bronze'),(76,0,30,'87305425',5010,'default','bronze'),(77,0,0,'진뚱이용',5000,'default','bronze'),(78,0,540,'88269663',5180,'default','bronze'),(79,0,1380,'코치',5460,'default','bronze'),(80,0,30,'68378870',5010,'default','bronze'),(81,0,540,'dd',5180,'default','bronze'),(82,0,0,'하하',5000,'default','bronze'),(83,0,30,'오오',5010,'default','bronze'),(84,0,30,'39554558',5010,'default','bronze'),(85,0,30,'하루에질문천개',5010,'default','bronze'),(86,0,750,'8803',5250,'default','bronze'),(87,0,30,'139624011',5010,'default','bronze'),(88,0,0,'gkdlgkdl',5000,'default','bronze'),(89,0,30,'125720796',5010,'default','bronze'),(90,0,60,'손종민',5020,'default','bronze'),(91,0,30,'q',5010,'default','bronze'),(92,0,0,'test중',5000,'default','bronze'),(93,0,0,'라고나',5000,'default','bronze'),(94,0,30,'77481223',5010,'default','bronze'),(95,0,30,'다나',5010,'default','bronze'),(96,0,30,'102934823',5010,'default','bronze'),(97,0,30,'62873925',5010,'default','bronze'),(98,0,30,'106508216',5010,'default','bronze'),(99,0,30,'아아리',5010,'default','bronze'),(100,0,30,'139304856',5010,'default','bronze'),(101,0,0,'asdqwe14',5000,'default','bronze'),(102,0,30,'박박박박',5010,'default','bronze'),(103,0,30,'ㅔ임스ㅈ',5010,'default','bronze'),(104,0,30,'화이팅',5010,'default','bronze'),(105,0,30,'test2',5010,'default','bronze'),(106,0,30,'54586491',5010,'default','bronze'),(107,0,0,'옥지얌',5000,'default','bronze'),(108,0,0,'mmth',5000,'default','bronze'),(109,0,30,'98978787',5010,'default','bronze'),(110,0,30,'83646178',5010,'default','bronze'),(111,0,1050,'김갈동',5350,'default','bronze'),(112,0,540,'햄스터',5180,'default','bronze');
/*!40000 ALTER TABLE `user_profile` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-16 10:38:27
