-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: decode-db.c5qy4qwy880z.ap-northeast-2.rds.amazonaws.com    Database: decodedb
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `chat`
--

DROP TABLE IF EXISTS `chat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_time` datetime(6) NOT NULL,
  `updated_time` datetime(6) NOT NULL,
  `message` varchar(255) DEFAULT NULL,
  `room_id` bigint DEFAULT NULL,
  `sender` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKq0wpdf7d0te1ub2uiq15i2raj` (`room_id`),
  KEY `FKklwbhtywpnykib3gc7bdccvou` (`sender`),
  CONSTRAINT `FKklwbhtywpnykib3gc7bdccvou` FOREIGN KEY (`sender`) REFERENCES `user_profile` (`user_id`),
  CONSTRAINT `FKq0wpdf7d0te1ub2uiq15i2raj` FOREIGN KEY (`room_id`) REFERENCES `chat_room` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=865 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat`
--

LOCK TABLES `chat` WRITE;
/*!40000 ALTER TABLE `chat` DISABLE KEYS */;
INSERT INTO `chat` VALUES (817,'2024-02-15 15:32:57.184653','2024-02-15 15:32:57.184653','simsim',65,12),(818,'2024-02-15 15:32:58.421069','2024-02-15 15:32:58.421069','하신가여',65,12),(819,'2024-02-15 16:02:26.600940','2024-02-15 16:02:26.600940','화면 공유방에 참여하시겠습니까? <span class=\"session-id\" hidden>68uxAIHZcc</span>\n        <button class=\"join-session\" style=\"color: blue\">참가하기</button>',65,78),(820,'2024-02-15 16:03:35.874756','2024-02-15 16:03:35.874756','화면 공유방에 참여하시겠습니까? <span class=\"session-id\" hidden>jDck1PQIC9</span>\n        <button class=\"join-session\" style=\"color: blue\">참가하기</button>',61,78),(821,'2024-02-15 16:04:06.767769','2024-02-15 16:04:06.767769','화면 공유방에 참여하시겠습니까? <span class=\"session-id\" hidden>xp6RehMDyK</span>\n        <button class=\"join-session\" style=\"color: blue\">참가하기</button>',65,78),(822,'2024-02-15 16:04:36.949873','2024-02-15 16:04:36.949873','ㅋㅋ',66,78),(823,'2024-02-15 17:12:37.437349','2024-02-15 17:12:37.437349','123123',59,79),(824,'2024-02-15 17:14:37.899808','2024-02-15 17:14:37.899808','화면 공유방에 참여하시겠습니까? <span class=\"session-id\" hidden>ZcbkkFXiXl</span>\n        <button class=\"join-session\" style=\"color: blue\">참가하기</button>',60,79),(825,'2024-02-15 17:15:03.198252','2024-02-15 17:15:03.198252','ㅇ',60,79),(826,'2024-02-15 17:20:01.759446','2024-02-15 17:20:01.759446','테테테테스트',60,4),(827,'2024-02-15 17:46:50.379965','2024-02-15 17:46:50.379965','화면 공유방에 참여하시겠습니까? <span class=\"session-id\" hidden>kJv4gD4MYt</span>\n        <button class=\"join-session\" style=\"color: blue\">참가하기</button>',65,84),(828,'2024-02-15 17:47:07.893281','2024-02-15 17:47:07.893281','..',62,84),(829,'2024-02-15 17:47:08.059336','2024-02-15 17:47:08.059336','.',62,84),(830,'2024-02-15 17:47:08.408339','2024-02-15 17:47:08.408339','.',62,84),(831,'2024-02-15 17:47:08.571603','2024-02-15 17:47:08.571603','.',62,84),(832,'2024-02-15 17:47:08.735801','2024-02-15 17:47:08.735801','.',62,84),(833,'2024-02-15 17:47:08.896002','2024-02-15 17:47:08.896002','.',62,84),(834,'2024-02-15 17:47:09.217339','2024-02-15 17:47:09.217339','..',62,84),(835,'2024-02-15 17:47:09.385725','2024-02-15 17:47:09.385725','.',62,84),(836,'2024-02-15 17:47:09.527121','2024-02-15 17:47:09.527121','.',62,84),(837,'2024-02-15 17:47:09.710211','2024-02-15 17:47:09.710211','.',62,84),(838,'2024-02-15 17:47:09.910727','2024-02-15 17:47:09.910727','..',62,84),(839,'2024-02-15 17:47:44.880599','2024-02-15 17:47:44.880599','l',56,84),(840,'2024-02-15 17:47:45.044749','2024-02-15 17:47:45.044749','l',56,84),(841,'2024-02-15 17:47:45.208771','2024-02-15 17:47:45.208771','l',56,84),(842,'2024-02-15 17:47:45.374491','2024-02-15 17:47:45.374491','l',56,84),(843,'2024-02-15 17:47:45.539750','2024-02-15 17:47:45.539750','l',56,84),(844,'2024-02-15 17:47:45.753740','2024-02-15 17:47:45.753740','ll',56,84),(845,'2024-02-15 17:48:20.105877','2024-02-15 17:48:20.105877','화면 공유방에 참여하시겠습니까? <span class=\"session-id\" hidden>OSl1weRCP8</span>\n        <button class=\"join-session\" style=\"color: blue\">참가하기</button>',56,84),(846,'2024-02-15 18:36:18.533317','2024-02-15 18:36:18.533317','헬로헬로',56,94),(847,'2024-02-15 18:36:31.467725','2024-02-15 18:36:31.467725','여기 랜덤채팅도 구현되있네',56,94),(848,'2024-02-15 18:36:51.143454','2024-02-15 18:36:51.143454','하이 록바이슨',56,94),(849,'2024-02-15 18:37:05.700439','2024-02-15 18:37:05.700439','화면 공유방에 참여하시겠습니까? <span class=\"session-id\" hidden>SuwVSSHkzl</span>\n        <button class=\"join-session\" style=\"color: blue\">참가하기</button>',56,94),(850,'2024-02-15 20:24:54.146827','2024-02-15 20:24:54.146827','테스트 good',60,9),(851,'2024-02-15 20:26:52.607279','2024-02-15 20:26:52.607279','화면 공유방에 참여하시겠습니까? <span class=\"session-id\" hidden>rpjnz5tAKs</span>\n        <button class=\"join-session\" style=\"color: blue\">참가하기</button>',60,9),(852,'2024-02-15 20:29:35.746813','2024-02-15 20:29:35.746813','화면 공유방에 참여하시겠습니까? <span class=\"session-id\" hidden>D44ty84uB4</span>\n        <button class=\"join-session\" style=\"color: blue\">참가하기</button>',60,9),(853,'2024-02-15 20:30:22.071309','2024-02-15 20:30:22.071309','화면 공유방에 참여하시겠습니까? <span class=\"session-id\" hidden>jQR9ZnH8GR</span>\n        <button class=\"join-session\" style=\"color: blue\">참가하기</button>',60,9),(854,'2024-02-15 20:30:44.395855','2024-02-15 20:30:44.395855','ㅎㅇㅎㅇㅎㅇ',56,99),(855,'2024-02-15 21:30:30.684990','2024-02-15 21:30:30.684990','화면 공유방에 참여하시겠습니까? <span class=\"session-id\" hidden>QQ7ymwTvij</span>\n        <button class=\"join-session\" style=\"color: blue\">참가하기</button>',56,1),(856,'2024-02-15 21:56:49.923476','2024-02-15 21:56:49.923476','하이요',68,36),(857,'2024-02-15 21:56:53.706956','2024-02-15 21:56:53.706956','하이요',68,2),(858,'2024-02-15 21:57:02.176647','2024-02-15 21:57:02.176647','뭐가궁금하시죠?',68,2),(859,'2024-02-15 21:57:09.620137','2024-02-15 21:57:09.620137','파이썬이 너무 어려워요 ㅠㅠ',68,36),(860,'2024-02-15 21:57:26.288267','2024-02-15 21:57:26.288267','화면 공유방에 참여하시겠습니까? <span class=\"session-id\" hidden>BJKugwauA3</span>\n        <button class=\"join-session\" style=\"color: blue\">참가하기</button>',68,2),(861,'2024-02-16 01:44:28.525886','2024-02-16 01:44:28.525886','화면 공유방에 참여하시겠습니까? <span class=\"session-id\" hidden>9Ur1rkipZd</span>\n        <button class=\"join-session\" style=\"color: blue\">참가하기</button>',56,3),(862,'2024-02-16 10:26:43.499607','2024-02-16 10:26:43.499607','안녕하세요',69,111),(863,'2024-02-16 10:26:45.607978','2024-02-16 10:26:45.607978','채팅방입니다',69,111),(864,'2024-02-16 10:27:13.124327','2024-02-16 10:27:13.124327','화면 공유방에 참여하시겠습니까? <span class=\"session-id\" hidden>BE6xkc99jD</span>\n        <button class=\"join-session\" style=\"color: blue\">참가하기</button>',69,111);
/*!40000 ALTER TABLE `chat` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-16 10:38:19
